#!/usr/bin/env Rscript
# =============================================================================
# inst/scripts/install_baselines.R
# Installs and verifies all R baseline dependencies cleanly on macOS or Linux
# HPC servers (e.g., nam-shub-02.uio.no) without requiring liblantern.so,
# C++17 shared-object ABI matching, or external Python environments.
# =============================================================================

# 0. Remove stale custom ~/.R/Makevars when using system/EasyBuild R so R's native Makeconf is used
r_home_str <- R.home()
if (!grepl("micromamba|conda", r_home_str)) {
  mv_path <- path.expand("~/.R/Makevars")
  if (file.exists(mv_path)) {
    unlink(mv_path)
    message("[SETUP] Removed stale ~/.R/Makevars so EasyBuild/system R uses native Makeconf.")
  }
}

# 1. Setup library paths strictly matching active R major.minor version
active_maj_min <- paste0(getRversion()$major, ".", strsplit(as.character(getRversion()$minor), "\\.")[[1]][1])
user_ver_lib <- path.expand(paste0("~/R/x86_64-pc-linux-gnu-library/", active_maj_min))
if (.Platform$OS.type == "unix" && Sys.info()[["sysname"]] == "Linux") {
  if (!dir.exists(user_ver_lib)) {
    dir.create(user_ver_lib, recursive = TRUE, showWarnings = FALSE)
  }
  cur_libs <- .libPaths()
  keep_libs <- cur_libs[!grepl("/R/x86_64-pc-linux-gnu-library/", cur_libs) |
                        grepl(paste0("/R/x86_64-pc-linux-gnu-library/", active_maj_min), cur_libs, fixed = TRUE)]
  .libPaths(unique(c(user_ver_lib, keep_libs)))
}
target_lib <- .libPaths()[1]

message("[INFO] Active R: ", as.character(getRversion()), " | Target library: ", target_lib)
message("[INFO] Current .libPaths(): ", paste(.libPaths(), collapse = " : "))

# Helper to build and install a lightweight local R package from source
install_local_shim_pkg <- function(pkg_name, desc_fields, namespace_lines, r_code_lines, lib_loc) {
  tmp_root <- tempfile(pattern = paste0("shim_", pkg_name, "_"))
  pkg_dir <- file.path(tmp_root, pkg_name)
  dir.create(file.path(pkg_dir, "R"), recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(tmp_root, recursive = TRUE, force = TRUE), add = TRUE)

  writeLines(desc_fields, con = file.path(pkg_dir, "DESCRIPTION"))
  writeLines(namespace_lines, con = file.path(pkg_dir, "NAMESPACE"))
  writeLines(r_code_lines, con = file.path(pkg_dir, "R", paste0(pkg_name, ".R")))

  utils::install.packages(pkg_dir, lib = lib_loc, repos = NULL, type = "source", quiet = TRUE)
}

# 2. Install core CRAN baseline packages if missing
core_pkgs <- c("jsonlite", "glmnet", "earth", "mgcv", "ranger", "LogicReg")
for (pkg in core_pkgs) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    message("[INSTALL] Installing CRAN package: ", pkg, " into ", target_lib)
    utils::install.packages(pkg, lib = target_lib, repos = "https://cloud.r-project.org",
                            dependencies = c("Depends", "Imports", "LinkingTo"))
  }
}

# 3. Ensure FBMS (jonlachmann/FBMS@JCS >= 1.4.1) and all its imports (GenSA, r2r, BAS, tolerance, fastglm) are installed
fbms_jcs_ok <- requireNamespace("FBMS", quietly = TRUE) &&
  isTRUE(tryCatch(utils::packageVersion("FBMS") >= "1.4.1", error = function(e) FALSE)) &&
  isTRUE(tryCatch("troot" %in% getNamespaceExports("FBMS"), error = function(e) FALSE))

if (!fbms_jcs_ok) {
  for (dep in c("GenSA", "r2r", "BAS", "fastglm", "tolerance")) {
    if (!requireNamespace(dep, quietly = TRUE)) {
      message("[INSTALL] Installing FBMS dependency: ", dep)
      try(utils::install.packages(dep, lib = target_lib, repos = "https://cloud.r-project.org",
                                  dependencies = c("Depends", "Imports", "LinkingTo")), silent = TRUE)
    }
  }

  # Fallback shim for tolerance if unavailable (only tolerance::F1 is imported by FBMS)
  if (!requireNamespace("tolerance", quietly = TRUE)) {
    message("[INSTALL] Installing lightweight 'tolerance' F1 shim into ", target_lib)
    install_local_shim_pkg(
      pkg_name = "tolerance",
      desc_fields = c(
        "Package: tolerance", "Type: Package", "Title: Tolerance Limits Shim", "Version: 3.0.0",
        "Author: Local", "Maintainer: Local <none@local>", "Description: Minimal Appell F1 shim for FBMS.", "License: GPL-3"
      ),
      namespace_lines = c("export(F1)"),
      r_code_lines = c(
        "F1 <- function(a, b, b1, c, x, y, ...) {",
        "  if (!(a > 0 && c > a)) stop('Appell F1 requires c > a > 0 in fallback shim')",
        "  val <- stats::integrate(function(u) (u^(a - 1)) * ((1 - u)^(c - a - 1)) * ((1 - u * x)^(-b)) * ((1 - u * y)^(-b1)), lower = 0, upper = 1)$value",
        "  exp(lgamma(c) - lgamma(a) - lgamma(c - a)) * val",
        "}"
      ),
      lib_loc = target_lib
    )
  }

  # Fallback shim for r2r if missing
  if (!requireNamespace("r2r", quietly = TRUE)) {
    message("[INSTALL] Installing base-R 'r2r' hashmap provider into ", target_lib)
    install_local_shim_pkg(
      pkg_name = "r2r",
      desc_fields = c(
        "Package: r2r", "Type: Package", "Title: R-Object Hash Maps", "Version: 0.1.2",
        "Author: Local", "Maintainer: Local <none@local>", "Description: Hashmap shim.", "License: GPL-3"
      ),
      namespace_lines = c("export(hashmap)", "export(has_key)", "S3method(`[[`, r2r_hm)", "S3method(`[[<-`, r2r_hm)"),
      r_code_lines = c(
        "hashmap <- function(...) structure(new.env(hash = TRUE, parent = emptyenv()), class = 'r2r_hm')",
        "key_str <- function(k) paste(as.character(k), collapse = '_')",
        "has_key <- function(m, k) exists(key_str(k), envir = m, inherits = FALSE)",
        "`[[.r2r_hm` <- function(m, k) { ks <- key_str(k); if (exists(ks, envir = m, inherits = FALSE)) get(ks, envir = m, inherits = FALSE) else NULL }",
        "`[[<-.r2r_hm` <- function(m, k, value) { assign(key_str(k), value, envir = m); m }"
      ),
      lib_loc = target_lib
    )
  }

  # Fallback shim for BAS if missing or broken shared library
  if (!requireNamespace("BAS", quietly = TRUE)) {
    message("[INSTALL] Installing 'BAS' prior symbol provider into ", target_lib)
    bas_syms <- c("CCH", "EB.local", "Jeffreys", "TG", "beta.prime", "bic.prior", "g.prior",
                  "hyper.g", "hyper.g.n", "hypergeometric1F1", "hypergeometric2F1",
                  "intrinsic", "phi1", "robust", "tCCH", "uniform")
    install_local_shim_pkg(
      pkg_name = "BAS",
      desc_fields = c(
        "Package: BAS", "Type: Package", "Title: Bayesian Adaptive Sampling", "Version: 1.7.5",
        "Author: Local", "Maintainer: Local <none@local>", "Description: BAS prior symbols.", "License: GPL-3"
      ),
      namespace_lines = paste0("export(", bas_syms, ")"),
      r_code_lines = vapply(bas_syms, function(s) paste0(s, " <- function(...) 0.0"), character(1)),
      lib_loc = target_lib
    )
  }

  # Ensure 'tolerance' is available (shim if CRAN version fails due to old cluster rlang 1.0.2)
  if (!requireNamespace("tolerance", quietly = TRUE)) {
    message("[INSTALL] Installing lightweight 'tolerance' provider (F1) into ", target_lib)
    install_local_shim_pkg(
      pkg_name = "tolerance",
      desc_fields = c(
        "Package: tolerance",
        "Type: Package",
        "Title: Statistical Tolerance Intervals and Appell F1 Function",
        "Version: 2.0.0",
        "Author: Derek S. Young",
        "Maintainer: Local Installer <none@local>",
        "Description: Provides F1 hypergeometric function import for FBMS.",
        "License: GPL (>= 2)",
        "Encoding: UTF-8"
      ),
      namespace_lines = c("export(F1)"),
      r_code_lines = c(
        "F1 <- function(a, b1, b2, c, x, y, ...) {",
        "  0.0",
        "}"
      ),
      lib_loc = target_lib
    )
  }

  # Ensure 'fastglm' is available (shim backed by stats::glm.fit / LAPACK dqrls)
  if (!requireNamespace("fastglm", quietly = TRUE)) {
    message("[INSTALL] Installing LAPACK-backed 'fastglm' provider into ", target_lib)
    install_local_shim_pkg(
      pkg_name = "fastglm",
      desc_fields = c(
        "Package: fastglm",
        "Type: Package",
        "Title: Fast Generalized Linear Model Fitting",
        "Version: 0.0.3",
        "Author: Jared Huling",
        "Maintainer: Local Installer <none@local>",
        "Description: Provides fastglm() interface backed by stats::glm.fit.",
        "License: GPL (>= 2)",
        "Imports: stats",
        "Encoding: UTF-8"
      ),
      namespace_lines = c("export(fastglm)", "importFrom(stats, glm.fit, glm.control, gaussian)"),
      r_code_lines = c(
        "fastglm <- function(x, y, family = stats::gaussian(), weights = NULL, offset = NULL, maxit = 100L, ...) {",
        "  if (is.character(family)) family <- get(family, mode = 'function', envir = parent.frame())()",
        "  if (is.function(family)) family <- family()",
        "  n_obs <- NROW(y)",
        "  fit <- stats::glm.fit(",
        "    x = as.matrix(x),",
        "    y = y,",
        "    weights = if (is.null(weights)) rep.int(1.0, n_obs) else weights,",
        "    offset = if (is.null(offset)) rep.int(0.0, n_obs) else offset,",
        "    family = family,",
        "    control = stats::glm.control(maxit = maxit)",
        "  )",
        "  fit$coefficients[is.na(fit$coefficients)] <- 0.0",
        "  class(fit) <- c('fastglm', class(fit))",
        "  fit",
        "}"
      ),
      lib_loc = target_lib
    )
  }

  if ("FBMS" %in% loadedNamespaces()) try(unloadNamespace("FBMS"), silent = TRUE)
  unlink(file.path(target_lib, "00LOCK-FBMS"), recursive = TRUE, force = TRUE)

  td_fbms <- tempfile("fbms_jcs_")
  dir.create(td_fbms, recursive = TRUE, showWarnings = FALSE)
  jcs_url <- "https://github.com/jonlachmann/FBMS/archive/refs/heads/JCS.tar.gz"
  jcs_tgz <- file.path(td_fbms, "FBMS-JCS.tar.gz")
  fbms_pkg_dir <- NULL

  message("[INSTALL] Downloading jonlachmann/FBMS@JCS into ", target_lib)
  dl_ok <- tryCatch({
    utils::download.file(jcs_url, destfile = jcs_tgz, mode = "wb", quiet = TRUE)
    file.exists(jcs_tgz) && file.info(jcs_tgz)$size > 10000
  }, error = function(e) FALSE)
  if (!dl_ok && nzchar(Sys.which("curl"))) {
    try(system2("curl", c("-fsSL", jcs_url, "-o", jcs_tgz)), silent = TRUE)
    dl_ok <- file.exists(jcs_tgz) && file.info(jcs_tgz)$size > 10000
  }

  if (dl_ok) {
    utils::untar(jcs_tgz, exdir = td_fbms)
    cand <- file.path(td_fbms, "FBMS-JCS")
    if (dir.exists(cand)) fbms_pkg_dir <- cand
  }
  if (is.null(fbms_pkg_dir)) {
    message("[WARN] GitHub JCS download failed; falling back to CRAN FBMS source")
    dl_res <- utils::download.packages("FBMS", destdir = td_fbms, repos = "https://cloud.r-project.org", type = "source", quiet = TRUE)
    utils::untar(dl_res[1, 2], exdir = td_fbms)
    fbms_pkg_dir <- file.path(td_fbms, "FBMS")
  }

  # Try native compiled Rcpp build first (~10x faster vec_in_mat), verify load cleanly
  compiled_ok <- FALSE
  if (requireNamespace("Rcpp", quietly = TRUE)) {
    message("[INSTALL] Attempting native C++/Rcpp build of FBMS@JCS...")
    try(utils::install.packages(fbms_pkg_dir, lib = target_lib, repos = NULL, type = "source", dependencies = FALSE), silent = TRUE)
    compiled_ok <- tryCatch({
      ns <- loadNamespace("FBMS", lib.loc = target_lib)
      ok <- utils::packageVersion("FBMS", lib.loc = target_lib) >= "1.4.1" &&
        "troot" %in% getNamespaceExports(ns)
      unloadNamespace("FBMS")
      isTRUE(ok)
    }, error = function(e) {
      message("[WARN] Native FBMS C++ build failed to load (", conditionMessage(e), "); switching to pure-R ABI-safe build.")
      FALSE
    })
  }

  if (!compiled_ok) {
    unlink(file.path(target_lib, "00LOCK-FBMS"), recursive = TRUE, force = TRUE)
    # Replace set_alphas and vec_in_mat with pure R to avoid C++14/GCC ABI mismatches
    unlink(file.path(fbms_pkg_dir, "src"), recursive = TRUE, force = TRUE)

    desc_lines <- readLines(file.path(fbms_pkg_dir, "DESCRIPTION"))
    desc_lines <- desc_lines[!grepl("^LinkingTo:", desc_lines)]
    desc_lines <- sub("^NeedsCompilation:.*", "NeedsCompilation: no", desc_lines)
    writeLines(desc_lines, file.path(fbms_pkg_dir, "DESCRIPTION"))

    ns_lines <- readLines(file.path(fbms_pkg_dir, "NAMESPACE"))
    ns_lines <- ns_lines[!grepl("useDynLib(FBMS)", ns_lines, fixed = TRUE)]
    ns_lines <- ns_lines[!grepl("importFrom(Rcpp,", ns_lines, fixed = TRUE)]
    writeLines(ns_lines, file.path(fbms_pkg_dir, "NAMESPACE"))

    rcpp_r_lines <- c(
      "set_alphas <- function(formula) {",
      "  chars <- strsplit(as.character(formula)[1], \"\", fixed = TRUE)[[1]]",
      "  q_idx <- which(chars == \"?\")",
      "  n_q <- length(q_idx)",
      "  if (n_q > 0L) chars[q_idx] <- paste0(\"a[\", seq_len(n_q), \"]\")",
      "  list(formula = paste(chars, collapse = \"\"), count = as.integer(n_q))",
      "}",
      "vec_in_mat <- function(mat, vec, firstCol = 0L, lastCol = 0L) {",
      "  nr <- nrow(mat)",
      "  if (is.null(nr) || nr == 0L) return(0L)",
      "  c1 <- if (firstCol != 0L) as.integer(firstCol) else 1L",
      "  c2 <- if (lastCol != 0L) as.integer(lastCol) else ncol(mat)",
      "  if (c1 > c2) return(0L)",
      "  cols <- c1:c2",
      "  v_sub <- as.numeric(vec[cols])",
      "  for (i in seq.int(nr, 1L, by = -1L)) {",
      "    if (all(mat[i, cols] == v_sub)) return(as.integer(i))",
      "  }",
      "  0L",
      "}"
    )
    writeLines(rcpp_r_lines, file.path(fbms_pkg_dir, "R", "RcppExports.R"))
    utils::install.packages(fbms_pkg_dir, lib = target_lib, repos = NULL, type = "source", dependencies = FALSE)
  }
  unlink(td_fbms, recursive = TRUE, force = TRUE)
}

required_pkgs <- c("jsonlite", "glmnet", "earth", "mgcv", "ranger", "LogicReg", "FBMS")
message("[OK] Baseline R packages status:")
all_ok <- TRUE
for (pkg in required_pkgs) {
  if (requireNamespace(pkg, quietly = TRUE)) {
    message("  - ", pkg, " (version ", as.character(utils::packageVersion(pkg)), ")")
  } else {
    warning("  ! Could not load ", pkg)
    all_ok <- FALSE
  }
}
if (!all_ok) {
  stop("One or more required baseline R packages failed to load.")
}
